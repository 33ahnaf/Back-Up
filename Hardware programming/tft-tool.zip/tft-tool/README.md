# Universal SPI TFT Auto-Detection Tool

Diagnostic firmware for the ESP32-WROOM-32 that identifies an unknown SPI
TFT panel by cycling through initialization sequences for every commonly
used controller, rather than relying on a single compile-time driver
selection (as TFT_eSPI requires).

## Supported controllers

ILI9341, ILI9486, ILI9488, ST7735, ST7789, HX8357, GC9A01.

## Wiring

Only 5 signals are needed - **no MISO**:

| Signal | Default GPIO (edit in `src/main.cpp`) |
|--------|----------------------------------------|
| CS     | 5  |
| DC     | 2  |
| RST    | 4  (set to `-1` if RST is tied to 3V3/EN) |
| MOSI   | 23 |
| SCK    | 18 |

Edit the constants in the `pins` namespace at the top of `src/main.cpp` to
match your actual wiring.

## How it works

`SPIBus` is a thin, allocation-free wrapper over the ESP32 hardware SPI
peripheral (command/data byte writes, chip-select/DC control, a reusable
pixel-fill routine). Every controller driver (`src/drivers/*`) subclasses
`DriverBase` and supplies only its own register init sequence; address
window, rotation (MADCTL), color order, inversion, and fill logic are all
implemented once in `DriverBase` since that command set is shared across
essentially all SPI TFT controllers. `Display` then drives the test loop:

```
forever:
  for each driver:
    hardware reset -> initialize()
    for each enabled rotation (0-3):
      for each enabled color order (RGB, BGR):
        for each enabled inversion (OFF, ON):
          fill RED -> GREEN -> BLUE -> WHITE -> BLACK (200ms each)
          [optional pattern tests]
```

Whichever combination shows correct, non-garbled colors on your physical
panel tells you the controller, rotation, color order, and inversion
setting to use going forward.

## Build

```
pio run -e esp32dev -t upload
pio device monitor
```

## Compile-time flags (`platformio.ini` `build_flags`)

| Flag | Effect |
|------|--------|
| `ENABLE_SERIAL_LOG`    | Verbose serial banner + per-color logging |
| `ENABLE_ROTATION_TEST` | Sweep all 4 rotations (otherwise only rotation 0) |
| `ENABLE_BGR_TEST`      | Sweep RGB and BGR color order (otherwise only RGB) |
| `ENABLE_INVERT_TEST`   | Sweep inversion OFF/ON (otherwise only OFF) |
| `ENABLE_PATTERN_TESTS` | Also run bar/checkerboard/diagonal/crosshair/gradient/moving-square patterns after the solid-color sequence |
| `ENABLE_SLOW_SPI`      | Force 8 MHz SPI clock |
| `ENABLE_FAST_SPI`      | Force 40 MHz SPI clock |

With no speed flag set, SPI defaults to 26 MHz - a safe middle ground for
auto-detection when wiring quality/length is unknown.

## Robustness

The loop never blocks on user input and never halts: there is no MISO line
to read status back from, so a missing/miswired panel simply results in
"nothing visibly happens" for that driver/combination rather than a hang or
crash, and the sweep moves on.
