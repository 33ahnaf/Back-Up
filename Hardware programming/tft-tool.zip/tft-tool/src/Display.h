#pragma once
// ============================================================================
// Display
//
// Orchestrates the universal auto-detection test loop described in the
// project spec: for every known driver, reset + initialize the panel, then
// sweep rotation x color-order x inversion, filling RED/GREEN/BLUE/WHITE/
// BLACK at each combination - forever, without ever stopping for input or
// crashing on a bad/absent panel.
// ============================================================================

#include <Arduino.h>
#include "DriverBase.h"
#include "SPIBus.h"

namespace tft {

class Display {
public:
    // drivers/driverCount: caller-owned array of driver pointers (typically
    // one statically-constructed instance per supported controller). This
    // class does not take ownership and allocates nothing itself.
    Display(SPIBus& bus, DriverBase* const* drivers, size_t driverCount);

    // Starts the SPI bus at the given frequency. Call once from setup().
    void begin(uint32_t spiFrequency);

    // Runs the full driver x rotation x color-order x invert x color sweep
    // exactly once, in order, over every configured driver.
    void runFullSweepOnce();

    // Runs runFullSweepOnce() in an infinite loop. Never returns.
    [[noreturn]] void runForever();

private:
    // Resets, initializes, and exercises a single driver across every
    // enabled rotation/color-order/invert combination.
    void testDriver(DriverBase& driver);

    // Fills RED -> GREEN -> BLUE -> WHITE -> BLACK, 200ms each, logging each
    // step, for the driver's *current* rotation/color-order/invert state.
    void runColorSequence(DriverBase& driver);

    SPIBus& _bus;
    DriverBase* const* _drivers;
    size_t _driverCount;
};

} // namespace tft
