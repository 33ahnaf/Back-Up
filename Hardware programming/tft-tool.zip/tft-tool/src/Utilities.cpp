#include "Utilities.h"

namespace tft {

void logTestBanner(const char* driverName, uint8_t rotation, bool bgr, bool invert) {
#if defined(ENABLE_SERIAL_LOG)
    Serial.println(F("========================="));
    Serial.print(F("Driver       : "));
    Serial.println(driverName);
    Serial.print(F("Rotation     : "));
    Serial.println(rotation);
    Serial.print(F("Color Order  : "));
    Serial.println(bgr ? F("BGR") : F("RGB"));
    Serial.print(F("Invert       : "));
    Serial.println(invert ? F("ON") : F("OFF"));
    Serial.println(F("========================="));
#else
    (void)driverName;
    (void)rotation;
    (void)bgr;
    (void)invert;
#endif
}

void logColorStep(const char* colorName) {
#if defined(ENABLE_SERIAL_LOG)
    Serial.println(colorName);
#else
    (void)colorName;
#endif
}

} // namespace tft
