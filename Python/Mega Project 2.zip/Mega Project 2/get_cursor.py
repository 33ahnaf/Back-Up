import pyautogui

while True:
    print(pyautogui.position())
    # 900, 742
    # 518, 160
    # 1297, 638
    # 917, 742




    # 896, 743 << Chrome icon

    # 529, 205   << Drag from
    # 1280, 639  << Drag to

    # 890, 165 << Random/Blank space
    # 721, 695 << Send section
    # 1326, 690 << Send button