from openai import OpenAI

command = '''
[3:18 pm, 6/2/2025] Afrina Rahman: I mean not very innocent as expected.
[4:35 pm, 6/2/2025] MD. Ahnaf Shariar: How can you conform that i'm not as innocent as expected.
[4:35 pm, 6/2/2025] MD. Ahnaf Shariar: have I ever said any bad things..
[5:55 pm, 6/2/2025] MD. Ahnaf Shariar: .
[5:56 pm, 6/2/2025] MD. Ahnaf Shariar: I noticed something SUS
[6:07 pm, 6/2/2025] MD. Ahnaf Shariar: veeryy… SuS
🤨
[6:18 pm, 6/2/2025] Afrina Rahman: What's that?
[6:19 pm, 6/2/2025] Afrina Rahman: I'm sorry 😐, I didn't mean to mock you 😔. I just said that for fun 😊.
[6:19 pm, 6/2/2025] Afrina Rahman: I hope you won't mind 🙏
[6:19 pm, 6/2/2025] MD. Ahnaf Shariar: it's ok
[6:20 pm, 6/2/2025] Afrina Rahman: In case you don't mind, can you share the solution of the math problem of majed sir
[6:20 pm, 6/2/2025] MD. Ahnaf Shariar: yes
[6:20 pm, 6/2/2025] MD. Ahnaf Shariar: that was a tuff one
[6:20 pm, 6/2/2025] Afrina Rahman: Yeah 👍
[6:21 pm, 6/2/2025] Afrina Rahman: What is it
[6:21 pm, 6/2/2025] MD. Ahnaf Shariar: S--U--S
[6:21 pm, 6/2/2025] Afrina Rahman: What is Sus I mean what do you find suspicious 🧐
[6:22 pm, 6/2/2025] MD. Ahnaf Shariar: I'm not gonna tell you that
[6:24 pm, 6/2/2025] Afrina Rahman: Why 🤯
[6:24 pm, 6/2/2025] Afrina Rahman: Am I not your good friend
[6:24 pm, 6/2/2025] MD. Ahnaf Shariar: yes you are
[6:25 pm, 6/2/2025] Afrina Rahman: Then why 😞
[6:25 pm, 6/2/2025] Afrina Rahman: Do you also like science 🔭🧪?
[6:26 pm, 6/2/2025] MD. Ahnaf Shariar: ABSOLOUTLY !
[6:27 pm, 6/2/2025] Afrina Rahman: I thought that a long time ago 😔
[6:32 pm, 6/2/2025] MD. Ahnaf Shariar: I also love Electronics
[6:36 pm, 6/2/2025] MD. Ahnaf Shariar: this things (the guy is a Electrical Engineer and a YouTuber)
[6:57 pm, 6/2/2025] MD. Ahnaf Shariar: Here you go
[8:01 pm, 6/2/2025] Afrina Rahman: Funny 🤣
[9:48 am, 7/2/2025] Afrina Rahman: You have 3 favourite subjects, if you like science you will be a scientist 🥼. If you like computer programming you will be a programmer. If you like electric you will be a mechanical engineer. So which occupation will you choose?
[10:07 am, 7/2/2025] MD. Ahnaf Shariar: idk 😅
[10:16 am, 7/2/2025] Afrina Rahman: What do you think about the subject drawings
[10:17 am, 7/2/2025] MD. Ahnaf Shariar: I'm worst at that
[10:20 am, 7/2/2025] Afrina Rahman: 🤣👍
[10:23 am, 7/2/2025] MD. Ahnaf Shariar: What are the things you like ?
[2:51 pm, 7/2/2025] Afrina Rahman: Drawing, dancing and singing 🎶
[9:33 pm, 7/2/2025] MD. Ahnaf Shariar: You know... Windows 10 will be officially discontinued by 14 October, 2025
[10:33 pm, 7/2/2025] Afrina Rahman: What 😮, why 😨
[10:36 pm, 7/2/2025] MD. Ahnaf Shariar: to forcefully promoting users to upgrade to Windows 11
[5:59 pm, 9/2/2025] MD. Ahnaf Shariar: What r u doin' rn?
[6:00 pm, 9/2/2025] MD. Ahnaf Shariar: watchin' Drama?
[6:53 pm, 9/2/2025] Afrina Rahman: Noh
[6:53 pm, 9/2/2025] Afrina Rahman: I'm very ill 🤒
[8:58 pm, 9/2/2025] MD. Ahnaf Shariar: Wishing you a speedy recovery!
'''

client = OpenAI(api_key="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")

completion = client.chat.completions.create(
  model="gpt-4o-mini",
  store=True,
  messages=[
      {"role": "system", "content": "You are a person named Ahnaf who speaks Bengali as well as English. He is from Bangladesh and he is a coder. You analyze chat history and respond like Ahnaf."},
      {"role": "user", "content": command}
  ]
)

print(completion.choices[0].message.content)

# First answer: [9:00 pm, 9/2/2025] MD. Ahnaf Shariar: Thanks for letting me know. Hope you feel better soon. If you need anything, just let me know! Take care of yourself, okay?
# Second answer: [9:00 pm, 9/2/2025] MD. Ahnaf Shariar: Thank you for the update! I’m really sorry to hear you’re not feeling well. Take care of yourself and make sure to get plenty of rest. If you need anything or just want to chat to distract yourself, I'm here! 😊