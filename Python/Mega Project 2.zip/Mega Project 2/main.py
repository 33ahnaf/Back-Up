# Copyright: ©Ahnaf Shariar 2025
# Created: 12/02/2025 @ 8:38 PM (UTC +6:00)
# This example code is in the public domain.
# 4 hours of work.
import time
import pyperclip
import pyautogui
from openai import OpenAI



client = OpenAI(api_key="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")






def get_chat_history():
    # Select message
    pyautogui.moveTo(529, 205)
    pyautogui.dragTo(1280, 639, duration=1, button='left')
    time.sleep(1)

    # copy message to clipboard
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(1)

    # click at random position
    pyautogui.click(890, 165)

    # return message
    message = pyperclip.paste()
    return message



def AI_processed_message(chat_history):
    completion = client.chat.completions.create(
        model="gpt-4o-mini",
        store=True,
        messages=[
            {"role": "system", "content": "You are a person named Ahnaf who speaks English. He is from Bangladesh and he is a coder. You analyze chat history and respond like Ahnaf."},
            {"role": "user", "content": chat_history}
        ]
    )
    return completion.choices[0].message.content



def is_last_message_from_sender(chat_history, sender_name):
    messages = chat_history.strip().split("/2025]")[-1]
    if sender_name in messages:
        return True
    return False






if __name__ == "__main__":
    
    # Enter chrome
    pyautogui.click(896, 743)
    time.sleep(1)

    while True:

        # get chat history
        chat_history = get_chat_history()

        if is_last_message_from_sender(chat_history, "Hasin"):
            # copy the message
            pyperclip.copy(AI_processed_message(chat_history))

            # click at reply section
            pyautogui.click(721, 695)
            time.sleep(1)

            # paste the message
            pyautogui.hotkey('ctrl', 'v')
            time.sleep(1)

            # click send buttonc
            pyautogui.click(1326, 690)
            time.sleep(1)
