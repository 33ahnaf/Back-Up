import time
import pyautogui
import pyperclip

pyautogui.click(900, 742)
time.sleep(1)

pyautogui.moveTo(518, 160)
pyautogui.dragTo(1297, 638, duration=1.0, button='left')

pyautogui.hotkey('ctrl', 'c')
# time.sleep(1)

pyautogui.click(518, 160)

pyautogui.click(917, 742)
time.sleep(1)

pyautogui.click(500, 300)
# time.sleep(1)

text = pyperclip.paste()
print(text)